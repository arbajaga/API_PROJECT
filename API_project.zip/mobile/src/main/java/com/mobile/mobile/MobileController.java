package com.mobile.mobile;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zaxxer.hikari.util.ClockSource.Factory;

@RestController
public class MobileController {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("getmobiles")
	public List<mobile> GetMobiles(){
		
		List<mobile> al=sf.openSession().createQuery("from mobile").list();
		System.out.println(al);
		
		return al;
	}

	

}
