package com.mobile.mobile;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class mobile {
	
	@Id
	Integer mobile_id;
	String Mobile_name;
	Integer speed;
	Integer price;
	public Integer getMobile_id() {
		return mobile_id;
	}
	public void setMobile_id(Integer mobile_id) {
		this.mobile_id = mobile_id;
	}
	public String getMobile_name() {
		return Mobile_name;
	}
	public void setMobile_name(String mobile_name) {
		Mobile_name = mobile_name;
	}
	public Integer getSpeed() {
		return speed;
	}
	public void setSpeed(Integer speed) {
		this.speed = speed;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "mobile [mobile_id=" + mobile_id + ", Mobile_name=" + Mobile_name + ", speed=" + speed + ", price="
				+ price + "]";
	}
	
	

}
