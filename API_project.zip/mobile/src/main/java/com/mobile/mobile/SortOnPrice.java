package com.mobile.mobile;

import java.util.Comparator;

public class SortOnPrice implements Comparator<mobile>{

	@Override
	public int compare(mobile mob1, mobile mob2) {
		
		Integer price1=mob1.price;
		Integer price2=mob2.price;
		
		Integer speed1=mob1.speed;
		Integer speed2=mob2.speed;
		
		if(price1.equals(price2))
			return -speed1.compareTo(speed2);
		return price1.compareTo(price2);
	}
	
	


}
