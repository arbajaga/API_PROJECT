package com.studentproject.student;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping("apicall")
public String apicall() {
		
		return "apicall";
	}
	
	@RequestMapping("Test")
	public ModelAndView test() {
		ArrayList<String> arrayList = new ArrayList();
		arrayList.add("Arbaj");
		arrayList.add("Kalyani");
		arrayList.add("Jemini");
		arrayList.add("Pranu");
		arrayList.add("Vaibhu");
		arrayList.add("Vivek");
		arrayList.add("Mayuri");
		arrayList.add("Priyanka");
		arrayList.add("Vaibhav");
		arrayList.add("Sayali");
		
		ModelAndView mv = new ModelAndView("test","data",arrayList);
		return mv;
	}
}
