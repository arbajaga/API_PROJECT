package com.studentproject.student;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

	@Autowired
	SessionFactory factory;

	List<Student> arraylist=null;
	public StudentController() {

	}


	@GetMapping("getallstudent")
	List allStudents() {

		Session s = factory.openSession();
		arraylist = s.createCriteria(Student.class).list();
		return arraylist;
	}
	@GetMapping("getstudent/{rno}")
	Student getstudent(@PathVariable int rno) {
		Session session=factory.openSession();
		Student s=session.load(Student.class, rno);

		return s;

	}
	@PostMapping("addstudent")
	public List<Student> addstudent(@RequestBody Student student) {
		{
			Session s=factory.openSession();
			org.hibernate.Transaction tt=s.beginTransaction();
			s.save(student);
			tt.commit();
			List<Student>list=allStudents();
			return list;

		}

	}

	@PutMapping("update")
	List<Student> updatStudents(@RequestBody Student stu){
		Session s = factory.openSession();
		org.hibernate.Transaction tt =s.beginTransaction();
		s.saveOrUpdate(stu);
		tt.commit();
		List<Student> list=allStudents();
		return list;
	}

	@DeleteMapping("delete/{rno}")
	    List<Student> deleteStudent(@PathVariable int rno){
		Session s=factory.openSession();
		Student ss= s.load(Student.class, rno);
		org.hibernate.Transaction tt=s.beginTransaction();
		s.delete(ss);
		tt.commit();

		List<Student> list=allStudents();
		return list;
	}		

}

